"""
NIDAQCTRL.py

Class to control the NI DAQ devices

Created on Feb 15, 2025 by Martin Ahrens
m.ahrens@uni-luebeck.de
"""

import nidaqmx
import nidaqmx.task
import logging
logger = logging.getLogger(__name__)

class NidaqHandle:
    """class NidaqHandle"""

    def __init__(
        self,
        device=str(),
        ao_channel=str(),
        ai_channel=str(),
        min_out=float,
        max_out=float,
    ) -> None:
        """
        Init NI-DAQ module

        Args:
            device     (str): Device name of the NI-DAQ modul, e.g. 'Dev1'
            ao_channel (str): Analog out channel, e.g. 'ao1'
            ai_channel (str): Analog in  channel, e.g. 'ai1'
            min_out  (float): Analog value minimal out
            max_out  (float): Analog value maximal out

        Return:
            NidaqHandle(device, ao_channel, ai_channel)
        """

        self.device = device
        logger.debug(f"NIDAQ DEV = {self.device}")

        self.ao = self.device + "/" + ao_channel
        self.ai = self.device + "/" + ai_channel

        
        logger.debug(f"[NIDAQ] Analog out channel is {self.ao}")
        logger.debug(f"[NIDAQ] Analog in  channel is {self.ai}")

        try:
            self.task_out = nidaqmx.Task()
            self.task_out.ao_channels.add_ao_voltage_chan(
                self.ao, min_val=min_out, max_val=max_out
            )
            self.task_in = nidaqmx.Task()
            self.task_in.ai_channels.add_ai_voltage_chan(self.ai)

            logger.debug("[NIDAQ] Initialize nidaq control")

        except Exception as e:
            logger.debug(f"[NIDAQ] An exception occurred -> {e}")
            logger.debug("[NIDAQ] self.task_out = None, self.task_in = None")
            self.task_out = None
            self.task_in = None
            raise

        except Exception as e:
            logger.debug(f"[NIDAQ] An exception occurred -> {e}")

    def set_position(self, analog_out_value: float) -> None:
        """
        Set position

        Args:
            analog_out_value (float): Output in 0 - 10 V
        """

        self.task_out.write(analog_out_value, auto_start=True)
        analog_in_value = self.task_in.read()

        logger.debug(f"[NIDAQ] Send data: {analog_out_value:f}")
        logger.debug(f"[NIDAQ] Acquired data: {analog_in_value:f}")

    def get_position(self) -> float:
        """
        Get position

        Args:
            None

        Returns:
            analog_in_value (float): Analog value: the step size in µm must be
                    calculated afterhands.
        """

        analog_in_value = self.task_in.read()

        logger.debug(f"[NIDAQ] Acquired data: {analog_in_value:f}")

        return analog_in_value

    def close(self) -> None:
        """
        Close NI-DAQ module
        """

        try:
            self.task_out.close()
        except Exception:
            pass

        try:
            self.task_in.close()
        except Exception:
            pass

        logger.debug("[NIDAQ] Close nidaq control")